"use client";

import Image from "next/image";
import { useState } from "react";
import { MdClose } from "react-icons/md";
import { useConnect, useAccount } from "@starknet-react/core";

interface ConnectModalProps {
  isModalOpen: boolean;
  setIsModalOpen: (isModalOpen: boolean) => void;
}

export default function ConnectWalletModal({
  isModalOpen,
  setIsModalOpen,
}: ConnectModalProps) {
  // StarkNet React hooks
  const { connect, connectors } = useConnect();
  const { isConnected, connector } = useAccount();

  // Local state for tracking selected wallet
  const [selectedWallet, setSelectedWallet] = useState(connectors?.[0] || null);
  const [activeWallet, setActiveWallet] = useState("argent-mobile");

  const handleOverlayClick = () => {
    setIsModalOpen(false);
  };

  const handleModalClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent closing modal when clicking inside
  };

  const handleWalletClick = (wallet: (typeof connectors)[0]) => {
    setActiveWallet(wallet.id);
    setSelectedWallet(wallet);
    // You can optionally trigger connect immediately, if desired:
    connect({ connector: wallet });
  };

  return (
    <div
      className={`fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4 ${
        isModalOpen ? "visible" : "hidden"
      }`}
      onClick={handleOverlayClick}
    >
      {/* Modal Container */}
      <div
        className="relative w-full max-w-[329px] mx-auto bg-[#1D2027] rounded-[16px] py-4 px-[26px] h-[308px]"
        onClick={handleModalClick}
      >
        {/* Close Button */}
        <button
          className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors rounded-full bg-[#383838] w-[30px] h-[30px] justify-center items-center flex"
          onClick={() => setIsModalOpen(false)}
        >
          <MdClose size={20} />
        </button>

        {/* Title */}
        <h2 className="text-white text-lg font-semibold mt-0.5 mb-2 text-center">
          Connect wallet
        </h2>

        {/* Subtitle */}
        <p className="font-medium text-[14px] text-white mt-2 mb-[32px] text-center justify-center opacity-60">
          Authenticate using your preferred wallet to access dApp features
        </p>

        {/* Wallet List */}
        <div className="flex flex-row gap-[7px] rounded-[20px] bg-[#FFFFFF1A] p-[10px] justify-center mb-4">
          {connectors.map((wallet) => (
            <div
              key={wallet.id}
              onClick={() => {
                handleWalletClick(wallet);
              }}
            >
              <button className="w-[80px] h-[80px] bg-[#1D2027] rounded-[16px] flex items-center gap-3 p-3 text-white hover:bg-[#393B3D] transition-colors">
                <Image
                  src={
                    typeof wallet.icon === "object"
                      ? wallet.icon.dark
                      : wallet.icon
                  }
                  alt={wallet.name || "Unknown Wallet"}
                  height={80}
                  width={80}
                />
              </button>
            </div>
          ))}
        </div>
        <p className="text-[#FFFFFF99] font-[400] text-center">
          By continuing, you agree to our{" "}
          <a href="#" className="text-white underline underline-offset-1">
            Terms of Service
          </a>{" "}
          and{" "}
          <a href="#" className="text-white underline underline-offset-1">
            Privacy policy
          </a>
        </p>
      </div>
    </div>
  );
}
