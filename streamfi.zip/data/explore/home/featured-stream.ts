export const featuredStream = {
  title: "Call of duty ; Modern Warfare LiveStream",
  thumbnail: "/Images/explore/home/featured-img.png?height=600&width=1200",
  isLive: true,
  streamerThumbnail:
    "/Images/explore/home/featured-profile.png?height=100&width=100",
};
