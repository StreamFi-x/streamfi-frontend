export const mockChatMessages = [
  {
    id: 1,
    username: "Wagner",
    message: "First viewer joining in today",
    color: "#9333ea",
  },
  { id: 2, username: "Wolf", message: "Wait crates ?", color: "#10b981" },
  {
    id: 3,
    username: "Wagner",
    message: "First viewer joining in today",
    color: "#9333ea",
  },
  { id: 4, username: "Cleo", message: "Nyo in epi biko", color: "#f59e0b" },
  { id: 5, username: "Cleo", message: "Nyo in epi biko", color: "#f59e0b" },
  {
    id: 6,
    username: "Spencer Smith",
    message: "what game are we streaming today ?",
    color: "#ef4444",
  },
  {
    id: 7,
    username: "Wagner",
    message: "First viewer joining in today",
    color: "#9333ea",
  },
  {
    id: 8,
    username: "Hack",
    message: "Send Funds here: 0x0d7f7a8d9a7f8d9a7f8d9a7f8d9a7f8d9a7f8d9a",
    color: "#3b82f6",
  },
  {
    id: 9,
    username: "Spencer Smith",
    message: "what game are we streaming today ?",
    color: "#ef4444",
  },
  {
    id: 10,
    username: "Spencer Smith",
    message: "what game are we streaming today ?",
    color: "#ef4444",
  },
  {
    id: 11,
    username: "Spencer Smith",
    message: "what game are we streaming today ?",
    color: "#ef4444",
  },
  {
    id: 12,
    username: "Wagner",
    message: "First viewer joining in today",
    color: "#9333ea",
  },
];