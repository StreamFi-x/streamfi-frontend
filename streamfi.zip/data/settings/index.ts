export const tabs = [
    { id: "Profile", route: "/settings/profile" },
    { id: "Notifications", route: "/settings/notifications" },
    { id: "Privacy & Security", route: "/settings/privacy" },
    { id: "Stream & Channel Preferences", route: "/settings/stream-Preference" },
    { id: "Appearance", route: "/settings/Appearance" },
    { id: "Connected Accounts", route: "/settings/connected-accounts" }
  ];