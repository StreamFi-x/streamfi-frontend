type TestimonialProps = {
  // username: string;
  image: string;
  // role: string;
  // comment: string | string[];
  // stars: number;
}

export const testimonial_content:TestimonialProps[] = [
  {
    image: "/Images/testimonial/yourmama.svg",
  },
  {
    image: "/Images/testimonial/richwilson.svg",
  },
  {
    image: "/Images/testimonial/johnnysin.svg",
  },
  {
    image: "/Images/testimonial/couchporaro.svg",
  },
  {
    image: "/Images/testimonial/blackest.svg",
  },
  {
    image: "/Images/testimonial/archie.svg",
  },
]