export const tokenUtilityData = [
    {
      title: "Staking",
      description: "Earn rewards by staking your tokens.",
    },
    {
      title: "Ad-Free Viewing",
      description: "Use tokens for a premium, ad-free experience.",
    },
    {
      title: "Tipping",
      description: "Support streamers directly with $STREAM tokens.",
    },
    {
      title: "Governance",
      description: "Vote on key decisions with your tokens.",
    },
  ];