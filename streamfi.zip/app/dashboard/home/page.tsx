import React from 'react'

function DashboardHome() {
  return (
    <div>DashboardHome</div>
  )
}

export default DashboardHome