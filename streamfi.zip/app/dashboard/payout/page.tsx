import React from 'react'

export default function Payout() {
  return (
    <div>Payout</div>
  )
}
