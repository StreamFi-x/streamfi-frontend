import React from 'react'
import ThemeSettingsPage from '@/components/settings/appearance/appearance'

const page = () => {
  return (
    <div>
        <ThemeSettingsPage />
    </div>
  )
}

export default page