export interface CardProps {
  icon: any;
  title: string;
  description: string;
}
